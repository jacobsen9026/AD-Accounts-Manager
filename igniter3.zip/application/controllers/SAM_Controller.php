<?php

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *     class Home extends BaseController
 *
 * For security be sure to declare any new methods as protected or private.
 *
 * @package CodeIgniter
 */


class SAM_Controller extends CI_Controller
{
	
	function __construct(){
		parent::__construct();
		$this->load->view('/common/pre/meta');
		$this->load->view('/common/pre/css');
		$this->load->view('/common/pre/js');
		$this->load->view('/common/header');
		$this->load->view('/common/nav');
	}
	function __construct(){
		$this->load->view('/common/footer');
	}
	
	
	

}
