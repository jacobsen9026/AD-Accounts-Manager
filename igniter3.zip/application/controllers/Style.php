<?php namespace App\Controllers;

class Style extends BaseController
{
	public function style()
	{
		return parent::getCSS();
	}

	//--------------------------------------------------------------------

}
