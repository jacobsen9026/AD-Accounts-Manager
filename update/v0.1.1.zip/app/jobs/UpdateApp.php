<?php


namespace app\jobs;


use System\Jobs\Job;

class UpdateApp extends Job
{

}