<?php


namespace App\Controllers\Jobs;


use App\Controllers\Controller;

class JobController extends Controller
{


}