<?php


namespace App\Api\Ad;


use System\Traits\DomainTools;

class ADApi
{
    use DomainTools;
}