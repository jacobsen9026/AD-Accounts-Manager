<?php

use App\Models\View\CardPrinter;

echo CardPrinter::printCard($this->districtUser, $this->user);
