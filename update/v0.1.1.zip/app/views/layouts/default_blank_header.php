<?php
echo $this->view("/layouts/head");
?>
<body class="bg-light">
<div class=" container-fluid centered px-0 px-sm-5 ">

    <div class=' centered text-center text_centered container container-fluid  mt-8 '>



