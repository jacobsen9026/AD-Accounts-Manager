<?php

echo $this->view("/layouts/default_footer");
?>
