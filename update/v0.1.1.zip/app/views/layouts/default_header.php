<?php
echo $this->view("/layouts/head");
?>
<body class="bg-light">
<div class="container container-fluid centered px-3 px-md-5">

    <div class=' centered text-center text_centered container container-fluid py-5 px-3 px-md-5 mt-8 mb-5 mx-auto shadow-lg bg-white'>



