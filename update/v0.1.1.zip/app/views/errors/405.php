<div class="container">
    <div>
        <h3>
            Method not implemented.

        </h3>
    </div>
    <div>

    </div>
    <div>

        The page you requested was unable to fully complete processing due to a lack of implementation for a requested
        function.<br/>
        <?= $this->route->getControler() . "->" . $this->route->getMethod(); ?>
    </div>
</div>
