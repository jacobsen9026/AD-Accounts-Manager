<?php


namespace App\App;


use System\Database;

class ConfigDatabase extends Database
{

}