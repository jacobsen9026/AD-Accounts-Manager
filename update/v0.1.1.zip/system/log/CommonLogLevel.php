<?php


namespace System\Log;


use Psr\Log\LogLevel;

class CommonLogLevel extends LogLevel
{

}