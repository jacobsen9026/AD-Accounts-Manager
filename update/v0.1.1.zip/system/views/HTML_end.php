<style>
    <?php

    include(ROOTPATH .
    DIRECTORY_SEPARATOR .
    "system" .
    DIRECTORY_SEPARATOR .
    "system.css"
    );
    ?>
</style>

</html>