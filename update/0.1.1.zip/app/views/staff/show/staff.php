<?php

use App\Models\View\CardPrinter;

echo CardPrinter::printCard($this->staff, $this->user);
