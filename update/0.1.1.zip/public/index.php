<?php

namespace System;

chdir("../");
require_once('system/Core.php');

$core = new Core();

$core->run();
?>