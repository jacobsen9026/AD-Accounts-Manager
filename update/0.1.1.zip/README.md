[![All Contributors](https://img.shields.io/badge/all_contributors-1-orange.svg?style=flat-square)](#contributors) 
<img style="margin-bottom:-5em;" src="https://github.com/jacobsen9026/AD-Accounts-Manager/raw/classify_cjacobsen/.github/images/adam.png" width=800/>

[Demo Website](http://demo.adam-app.gq/)
# Active Directory Accounts Manager
This is a dev branch that is the current active branch.

I've decided to build a custom framework for this project.

<img src="https://github.com/jacobsen9026/School-Accounts-Manager/blob/classify_master/.github/images/1.png?raw=true" width=800/>
<img src="https://github.com/jacobsen9026/School-Accounts-Manager/blob/classify_master/.github/images/2.png?raw=true" width=800/>
<img src="https://github.com/jacobsen9026/School-Accounts-Manager/blob/classify_master/.github/images/3.png?raw=true" width=800/>
<img src="https://github.com/jacobsen9026/School-Accounts-Manager/blob/classify_master/.github/images/4.png?raw=true" width=800/>
<img src="https://github.com/jacobsen9026/School-Accounts-Manager/blob/classify_master/.github/images/5.png?raw=true" width=800/>

# UML

<img src="https://github.com/jacobsen9026/School-Accounts-Manager/blob/classify_master/.github/images/uml.png?raw=true" width=800/>



