<?php

?>
<div id="proxyForm">
    <form class="proxyFormPremium" method="post" id="request" action="servers">
        <div class="input-group input-group-lg">
            <input id="url" value="" name="url" type="text" class="form-control input-lg"
                   placeholder="Enter an URL or a search query to access">
            <span class="input-group-btn">
                    <button id="requestSubmit" type="submit" class="btn btn-primary btn-lg"><i class="fa fa-arrow-right"
                                                                                               aria-hidden="true"></i> Go!</button>
                </span>
        </div>
    </form>
    <div class="clearfix">
        <div class="proxyFormPremiumButton clearfix">
            <a href="account/registration/form" class="btn btn-primary btn-lg" data-trans="no"><i class="fa fa-star"
                                                                                                  aria-hidden="true"></i>
                Premium</a>
        </div>
    </div>
    <div id="zapperBottom">
        <div id="zapper" class="">

            <script async="" src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
            <script>
                (adsbygoogle = window.adsbygoogle || []).push({
                    google_ad_client: "ca-pub-4989892168778415",
                    enable_page_level_ads: true
                });
            </script>

            <script async="" src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
            <!-- index-media-bottom-croxy -->
            <ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-4989892168778415"
                 data-ad-slot="8350989238" data-ad-format="auto" data-full-width-responsive="false"></ins>
            <script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>


        </div>
    </div>
    <div id="quickLinks">
        Quick links:
        <a data-trans="no" class="proxyLink" data-href="https://www.google.com/">Google</a>, <a data-trans="no"
                                                                                                class="proxyLink"
                                                                                                data-href="https://www.youtube.com/">Youtube</a>,
        <a data-trans="no" class="proxyLink" data-href="https://www.facebook.com/">Facebook</a>, <a data-trans="no"
                                                                                                    class="proxyLink"
                                                                                                    data-href="https://www.wikipedia.org/">Wikipedia</a>,
        <a data-trans="no" class="proxyLink" data-href="https://www.reddit.com/">Reddit</a>, <a data-trans="no"
                                                                                                class="proxyLink"
                                                                                                data-href="https://www.instagram.com/">Instagram</a>,
        <a data-trans="no" class="proxyLink" data-href="https://twitter.com/">Twitter</a>, <a data-trans="no"
                                                                                              class="proxyLink"
                                                                                              data-href="https://www.gmail.com/">Gmail</a>,
        <a data-trans="no" class="proxyLink" data-href="https://imgur.com/">Imgur</a>, <a data-trans="no"
                                                                                          class="proxyLink"
                                                                                          data-href="https://www.dailymotion.com/">DailyMotion</a>,
        <a data-trans="no" class="proxyLink" data-href="https://www.twitch.tv/">Twitch</a></div>
</div>