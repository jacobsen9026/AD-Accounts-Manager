<?php
echo $this->view("/layouts/head");
?>

<body class="bg-light">
<div class
"container-fluid centered px-0 px-md-5">

<div class=' centered text-center text_centered container container-fluid py-5 px-0 px-md-5 mt-5 mt-md-8 mb-5 mx-auto col-sm-6 col-md-5 col-lg-4 shadow-lg bg-white'>



